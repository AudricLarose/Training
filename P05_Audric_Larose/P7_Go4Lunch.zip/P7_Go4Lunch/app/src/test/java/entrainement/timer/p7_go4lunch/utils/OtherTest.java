package entrainement.timer.p7_go4lunch.utils;

import static org.junit.Assert.*;

public class OtherTest {

}