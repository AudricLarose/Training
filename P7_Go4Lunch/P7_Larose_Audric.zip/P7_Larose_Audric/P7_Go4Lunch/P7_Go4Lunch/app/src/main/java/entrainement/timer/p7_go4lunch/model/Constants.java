package entrainement.timer.p7_go4lunch.model;

public class Constants {
        public static final String URL= "https://maps.googleapis.com/maps/api/place/details/json?place_id=ChIJN1t_tDeuEmsRUsoyG83frY4&fields=name,geometry,id,website,types,formatted_phone_number&key=AIzaSyC85iU9E8o4rOCwv2UurWP31fGXaTRcL8c";
        public static final int LIMIT=30;
}
